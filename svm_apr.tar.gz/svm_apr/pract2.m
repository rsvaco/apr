#!/usr/bin/octave -q


load("data/mini/tr.dat");
load("data/mini/trlabels.dat");

C = 1000;

res = svmtrain(trlabels, tr, '-t 0 -c 1000');

plot(tr(trlabels==1,1),tr(trlabels==1,2),"or",tr(trlabels==2,1), tr(trlabels==2,2),"ob", tr(res.sv_indices,1),tr(res.sv_indices,2), "xg")

multLagrange = res.sv_coef
vectoresSoporte = res.sv_indices; #res.SVs
indices = vectoresSoporte;
teta1 = tr(indices,1)' * multLagrange #clase*vectoressoporte*multlagrange
teta2 = tr(indices,2)' * multLagrange


for i = 1:rows(indices)
    if abs(multLagrange(i)) > 0 && abs(multLagrange(i)) < C
        teta0 = trlabels(indices(i)) - [teta1, teta2] * tr(indices(i),:)'
    	break;
    endif
endfor

umbral = teta0
margen = 2 / sqrt(teta1*teta1 + teta2*teta2)

tolerancias = diag(1 - trlabels * ([teta1, teta2] * tr' + teta0))(indices,:)

#plot(tr(trlabels==1,1),tr(trlabels==1,2),"or",
#tr(trlabels==2,1), tr(trlabels==2,2),"ob",
#tr(res.sv_indices,1),tr(res.sv_indices,2), "xg",
#
#)



