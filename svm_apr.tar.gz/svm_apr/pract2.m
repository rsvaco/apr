#!/usr/bin/octave -q


load(data/mini/trSep.dat);
load(data/mini/trSeplabels.dat);

res = svmtrain(trlabels, tr, '-t 0 -c 1000');

#plot(tr(trlabels==1,1),tr(trlabels==1,2),"x",tr(trlabels==2,1), tr(trlabels==2,2),"s", tr(res.sv_indices,1),tr(res.sv_indices,2), "p");

multLagrange = res.sv_coef;
vectoresSoporte = res.sv_indices; #res.SVs
indices = vectoresSoporte;
teta1 = tr(indices)' * multLagrange #clase*vectoressoporte*multlagrange
